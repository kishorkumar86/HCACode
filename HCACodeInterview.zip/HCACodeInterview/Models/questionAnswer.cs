﻿namespace HCACodeInterview.Models
{
    public class questionAnswersTable
    {
        public int ID { get; set; } 
        public string? Question { get; set; }
        public string? Answer { get; set; }

    }
}
