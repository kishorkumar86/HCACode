﻿namespace HCACodeInterview.Models
{
    public class FeedBackTable
    {
        public int Id { get; set; }
        public string ReviewerName { get; set; }
        public string FeedbackText { get; set; }
        public DateTime DateTime { get; set; }
    }
}
